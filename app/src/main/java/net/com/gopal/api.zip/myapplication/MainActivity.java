package net.com.gopal.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

   EditText Username, Password;
   MaterialButton loginbtn;
    private TextView signup;
    DatabaseHelp databaseHelp;
    TextView forgetpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Username = findViewById(R.id.Username);
       Password = findViewById(R.id.password);
         loginbtn = findViewById(R.id.loginbtn);
        signup = findViewById(R.id.signup);
        forgetpass = findViewById(R.id.forgetpass);
        databaseHelp = new DatabaseHelp(this);


        loginbtn.setOnClickListener(view -> {
//            String userName= Username.getText().toString();
//            String password = Password.getText().toString();
//
//
//            if (TextUtils.isEmpty(userName) || TextUtils.isEmpty(password)) {
//                Toast.makeText(MainActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
//            }
//
//                else
//                {
//                    Boolean checkUserPass = databaseHelp.checkUserPassword(userName,password);
//                    if (checkUserPass == true){
//                        Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(this,home.class);
                        startActivity(intent);
//                    }
//                    else{
//
//                        Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
//                    }
//                }
        });

        signup.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, signup.class);
            startActivity(intent);


        });

        forgetpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ForgetPassword.class);
                startActivity(intent);
            }
        });


    }



}