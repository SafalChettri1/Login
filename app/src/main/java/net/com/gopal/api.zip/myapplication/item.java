package net.com.gopal.myapplication;

public class item {

    String name;
    int image1;
    int date;
    String name2;
    int image2;
    int date2;

    public item(String name, int image1, int date) {
        this.name = name;
        this.image1 = image1;
        this.date = date;
        this.name2 = name2;
        this.image2 = image2;
        this.date2 = date2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage1() {
        return image1;
    }

    public void setImage1(int image1) {
        this.image1 = image1;
    }

    public int getImage2() {
        return image2;
    }

    public void setImage2(int image2) {
        this.image2 = image2;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public int getDate2() {
        return date2;
    }

    public void setDate2(int date2) {
        this.date2 = date2;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }
}
