package net.com.gopal.myapplication.api;

public class Utills {
    public static final String BASE_API= "https://restrotest.qpaysolutions.net/api/";
    public static final String MENU= BASE_API + "MerchantRestaurant/GetMenuAndCategory2";

}
