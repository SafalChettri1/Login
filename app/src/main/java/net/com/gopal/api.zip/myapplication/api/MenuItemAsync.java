package net.com.gopal.myapplication.api;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MenuItemAsync extends AsyncTask<String, String, String> {

    private Context context;
    private GetMenuItemInterface getMenuItemInterface;

    private JSONObject jsonObject;

    public MenuItemAsync(Context context, JSONObject jsonObject,GetMenuItemInterface getMenuItemInterface) {
        this.context = context;
        this.getMenuItemInterface = getMenuItemInterface;
        this.jsonObject = jsonObject;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

    }

    @Override
    protected String doInBackground(String... strings) {
        String response = null;
        try {
            response = httpClass.sendHTTPData(Utills.MENU, jsonObject);
            Log.d("Gopal", "response : " + response);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        try {
            JSONObject jsonObject = new JSONObject(s);
            String status = jsonObject.getString("status");
            String message = jsonObject.getString("message");
            if (status.equals("200")) {
//                JSONArray dataJSONArray = jsonObject.getJSONArray("data");
                JSONArray menuCategories = jsonObject.getJSONObject("data").getJSONArray("MenuCategories");

                List<MenuModel> MenuModel = new ArrayList<>();

                for (int i = 0; i < menuCategories.length(); i++) {
                    JSONObject category = menuCategories.getJSONObject(i);
                    String categoryName = category.getString("Category");
                    String iconURL = category.getString("IconUrl");
                    String categoryId = category.getString("CategoryId");

                    // Create a MenuModel object and add it to the list
                    MenuModel menuModel = new MenuModel(categoryName, iconURL, categoryId);
                    MenuModel.add(menuModel);

                }
                getMenuItemInterface.OnSuccess(message,MenuModel);


            } else {
                getMenuItemInterface.OnFail(message);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error" + e);
        }
    }


    public interface GetMenuItemInterface {
        void OnSuccess(String msg, List<MenuModel> Order);

        void OnFail(String msg);
    }
    // Add any required post-execution code here
}