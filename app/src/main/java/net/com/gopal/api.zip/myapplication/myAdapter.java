package net.com.gopal.myapplication;

import android.content.ClipData;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import net.com.gopal.myapplication.api.MenuModel;

import java.util.ArrayList;

import com.squareup.picasso.Picasso;


public class myAdapter extends RecyclerView.Adapter<myviewHolder> {


    Context context;
    ArrayList<MenuModel> menuList;

    public myAdapter(Context context, ArrayList<MenuModel> menuList) {
        this.context = context;
        this.menuList = menuList;
    }

    @NonNull
    @Override
    public myviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new myviewHolder(LayoutInflater.from(context).inflate(R.layout.itemview, parent, false));

    }

    @Override
    public void onBindViewHolder(@NonNull myviewHolder holder, int position) {
        MenuModel menuModel = menuList.get(position);

        holder.Category.setText(menuModel.getCategory());
        holder.CategoryID.setText(menuModel.getCategoryId());


        Picasso.get().load(menuModel.getIconURL()).into(holder.IconImageView);
//        holder.name.setText(items.get(position).getName());
//        holder.date.setText(String.valueOf(items.get(position).getDate())); // Convert int to String
//        holder.imageView.setImageResource(items.get(position).getImage1());
//        holder.imageView2.setImageResource(items.get(position).getImage2());
//        holder.date2.setText(String.valueOf(items.get(position).getDate2()));
//        holder.name2.setText(items.get(position).getName2());

    }


    @Override
    public int getItemCount() {
        return menuList.size();
    }
}
