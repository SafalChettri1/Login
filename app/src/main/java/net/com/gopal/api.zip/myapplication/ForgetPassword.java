package net.com.gopal.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ForgetPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
    }
}